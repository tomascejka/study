#!/bin/sh
mvn clean package && docker build -t cz.tc.docker.learn/simplest-guide .
docker rm -f simplest-guide || true && docker run -d -p 8080:8080 -p 4848:4848 --name simplest-guide cz.tc.docker.learn/simplest-guide 
