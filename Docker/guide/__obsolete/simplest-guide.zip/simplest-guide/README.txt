# Basics

## Build image
mvn clean package && docker build -t cz.tc.docker.learn/simplest-guide .

Parametr -t znamena:  -t, --tag list  Name and optionally a tag in the 'name:tag' format, pod timto nazve bude ulozena jako IMAGE

## Run container
docker rm -f simplest-guide || true && docker run -d -p 8080:8080 -p 4848:4848 --name simplest-guide cz.tc.docker.learn/simplest-guide

Parametry znamenaji:
 -f, --force          Force the removal of a running container (uses SIGKILL)
 -d, --detach         Run container in background and print container ID
 -p, --publish list   Publish a container's port(s) to the host
--name string         Assign a name to the container

Usage:  docker run [OPTIONS] IMAGE [COMMAND] [ARG...]

## Zdroje
1. https://docs.docker.com/get-started/part2/#build-and-test-your-image
2. https://docs.docker.com/get-started/part2/#run-your-image-as-a-container