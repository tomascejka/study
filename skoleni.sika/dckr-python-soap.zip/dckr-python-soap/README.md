Zdroje
* https://hub.docker.com/_/python
* https://czsodexo.atlassian.net/browse/IT-15691?focusedCommentId=322520